package com.todotask;

import java.awt.AWTException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.baseclassatlas.Robot;

public class MainTodo {
	
	    public static WebDriver driver;
		
		//Scenario 1:Initialize the state browser setup and launch the url
		
		@BeforeClass
		public static void initialize_The_driver_launch_browser() {
			
			//Test step1:Intialize the web driver and //Test step2:User Launch the Browser
		    driver=new FirefoxDriver();
		    //maximize the browser
			driver.manage().window().maximize();
			//using implicit wait
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			
			//Test step3:User Enter the Valid Url
			driver.get("https://todomvc.com/examples/angular/dist/browser/#/all");
		}
		
		//Scenario 2:Add a ToDo
		@Test(priority=1)
		public static void add_To_Do_list() throws AWTException {
			//Test step2:User enter the valid data to add the text field
			WebElement textBox=driver.findElement(By.xpath("//input[@placeholder='What needs to be done?']"));
			textBox.sendKeys("Drink Water every hour");
			//Test step3:user hit enter the item is added to th list
			Robot r=new Robot();
			r.keyEnter(textBox);
			
			//Test step4:user validate the text enter to the field or not
			SoftAssert s=new SoftAssert();
			String actual=textBox.getText();
			String expected="Drink Water every hour";
			s.assertNotEquals(actual, expected, "text enter to the valid field");
			s.assertAll();
			
		}
		//Scenario 3: mark an item as complete
		@Test(priority=2)
			public static void mark_An_Item_As_Complete() {
			WebElement checkBox=driver.findElement(By.xpath("(//input[@type='checkbox'])[2]"));
			checkBox.click();
		}
		
		//Scenario 4:Delete an item -click on the x to the right of the item
		
		@Test(priority=3)
			public static void delete_An_Item() {
			//Test step1: user able to hoever the mouse to X(delete)
			//using Actions class
				Actions a =new Actions(driver);
				WebElement delete=driver.findElement(By.xpath("//button[@class='destroy']"));
				a.moveToElement(delete).perform();
				//Test step2: User delete the item
				a.click(delete).perform();
				SoftAssert sq=new SoftAssert();
				sq.assertTrue(true, "item got deleted successfully");
				sq.assertAll();
			}
		
		//after delete the to do list again enter the same text to TO-Do for accessing filter(priority=5)
		@Test(priority=4)
		public static void again_pass_after_delete_add_To_Do_list() throws AWTException {
			//Test step2:User enter the valid data to add the text field
			WebElement textBox=driver.findElement(By.xpath("//input[@placeholder='What needs to be done?']"));
			textBox.sendKeys("Drink Water every hour");
			//Test step3:user hit enter the item is added to th list
			Robot r=new Robot();
			r.keyEnter(textBox);
			
			
		}
		
		@Test(priority=5)
			public static void filter_Click_ActiveButtons() {
			//active button click
			WebElement active=driver.findElement(By.xpath("//a[@class='selected']"));
			active.click();
			SoftAssert sa=new SoftAssert();
			sa.assertTrue(true,"click on the active button");
			
			
			//click completed button
			WebElement complete=driver.findElement(By.xpath("//a[@href='#/completed']"));
			complete.click();
			String actual=complete.getText();
			String expected="complete";
			sa.assertNotEquals(actual, expected, "verify user click the complete button successfully");
			sa.assertAll();
			}
		
		@AfterTest
		public static void quit_browser() {
			driver.quit();
		}
		
		
		
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		


